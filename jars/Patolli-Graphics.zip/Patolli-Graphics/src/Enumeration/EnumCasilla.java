
package Enum;

/**
 *
 * @author laura
 */
public enum EnumCasilla {
    FINAL, APUESTA, INICIO, CENTRAL, ESQUINA 
}
