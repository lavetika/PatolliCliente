/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Graphics;

import java.awt.Color;
import javax.swing.JPanel;

/**
 *
 * @author Zannie
 */
public class Chat extends JPanel {

    public Chat() {
        setSize(300, 600);
        setBackground(new Color(105, 2, 5));
        this.setLocation(900, 0);
    }

}
